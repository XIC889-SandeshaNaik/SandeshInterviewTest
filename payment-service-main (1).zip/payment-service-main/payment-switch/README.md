Fake Payment Switch
----

Install `json-server`

```
npm install -g json-server
```

Next, you can run the fake Payment Switch using

```
json-server db.json --routes routes.json --port 9898
```